Dungeon Craft Design Info

This design requires several files to operate successfully. The folder of the design you wish to play should contain the following:

ReadMe.txt (this file)
UAFWin.exe (the Dungeon Craft executable)
/Data (this folder contains all of the games data files that are needed by the executable)
/Resources (this folder contains all art - graphics and sounds - needed by the game)
/Saves (this folder contains any saved characters or games which may have been included by the design creator)

If you wish to check for an updated version of the Dungeon Craft executable, check out the 'Download' area of our home page - http://uaf.sourceforge.net

If you need help with the game you are playing, please contact the game's author. But if you need help with Dungeon Craft, or wish to learn more including how to make your own games to play, please check out the following locations, all of which are maintained by project developers.
DC Home Page - http://uaf.sourceforge.net
SourceForge DC Help Forums - http://sourceforge.net/projects/uaf/forums/forum/4979
DC Community mailing list - http://tech.groups.yahoo.com/group/UAForever/

If you wish to start creating your own games with Dungeon Craft, please download the most recent version of DC, read through the Help Documents and start creating! Any and all questions welcomed.
Editor Download - http://sourceforge.net/projects/uaf/files/
Community Forums:
FRUA Community - http://ua.reonis.com/index.php
DC on facebook - https://www.facebook.com/DungeonCraft

We look forward to hearing from you. Enjoy your game!

-DC Development Team
